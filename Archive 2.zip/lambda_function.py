import sys
import logging
import pymysql
import json
import os
import hashlib
from auth import generateToken
from auth import authenticateToken
from util import buildResponse


# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_proxy_host = os.environ['RDS_PROXY_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
        conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")

#default headers:
headers = {
            'Content-Type' :'application/json',
            'Access-Control-Allow-Origin' : '*'
}

def lambda_handler(event, context):


    
    logger.info(event)
    message = event['body']
    if message is None:
        
        return buildResponse(401, headers, {'message':'Empty body'})
    data = json.loads(message)
    
    path = event['path']
    httpMethod = event['httpMethod']
    
    if httpMethod == 'GET' and path == '/health':
        response = buildResponse(200, headers, {'message': 'Health Check'})

    elif httpMethod == 'POST' and path == '/user/register':

        if 'nombre_usuario' in data and 'email_usuario' in data and 'contraseña_usuario' in data:
            nombre = data['nombre_usuario']
            email = data['email_usuario']
            contraseña = data['contraseña_usuario']
        else:
            return buildResponse(401,headers,{'message' :'All fields requiered'})
        
        if getUserByEmail(email):
            return buildResponse(401,headers,{'message' :'Email is already in use'})
        
        response = createUser(nombre,email,contraseña)

    elif httpMethod == 'POST' and path == '/user/login':
        email = data['email_usuario']
        contraseña = data['contraseña_usuario']

        try:
            with conn.cursor() as cur:
                cur.execute("SELECT contraseña_usuario FROM usuarios WHERE email_usuario = %s", (email,))
                stored_password_hash = cur.fetchone()
                contraseña_bytes = contraseña.encode('utf-8')
                if stored_password_hash:
                    stored_password_hash = stored_password_hash[0]
                    if hashlib.blake2b(contraseña_bytes).hexdigest() == stored_password_hash:
                        del stored_password_hash
                        accessToken = generateToken(email)
                        response = buildResponse(200,headers, {'email': email,'accessToken': accessToken})
                    else:
                        return buildResponse(403,headers,{'message': 'Invalid Credentials'})
                else:
                    return buildResponse(403,headers,{'message': 'Invalid Credentials'})
        except Exception as e:
            return buildResponse(500,headers,{'message': "DB Server Error :("})
        
    elif httpMethod == 'POST' and path == '/verify':

        response = buildResponse(200,headers)
    elif httpMethod == 'PATCH' and path == '/user':
        
        response = buildResponse(200,headers)
    else:
        response = buildResponse(404, headers,{'message': 'Not Found'})

    return response



def createUser(nombre,email,contraseña):
    try:
        contraseña_bytes = contraseña.encode('utf-8')
        hashed_password = hashlib.blake2b(contraseña_bytes).hexdigest()
        with conn.cursor() as cur:
            sql_string = "INSERT INTO usuarios (nombre_usuario, puntos_usuario, email_usuario, contraseña_usuario) VALUES (%s, 0, %s, %s)"
            cur.execute(sql_string, (nombre, email, hashed_password))
            conn.commit()

            sql_string = "SELECT * FROM usuarios WHERE email_usuario = %s"
            cur.execute(sql_string, (email,))

            logger.info("The following items have been added to the database:")
            logger.info(cur)
        return buildResponse(200,headers,{'message': 'Se ha creado el usuario %s' % nombre})
    except Exception as e:
        return buildResponse(500, headers,{'error': str(e)})
    #tratar errores

def getUserByEmail(email):

    with conn.cursor() as cur:
        sql_string = "SELECT * FROM usuarios WHERE email_usuario = %s"
        cur.execute(sql_string, (email,))
        user = cur.fetchone()
        if user:
            return user
        else:
            return None
        
