import jwt
import logging
import os
from datetime import datetime, timedelta

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def generateToken(email):
    if not email:
        return None
    try:
        token_data = {'email': email,'exp': datetime.utcnow() + timedelta(hours=1)}
        token = jwt.encode(token_data, os.environ['JWT_SECRET'], algorithm='HS256')
        logger.info(token)
    except Exception as e:
        logger.info(e)
        return None
    return token

def authenticateToken(email, token):
    try:
        decoded = jwt.decode(token, os.environ['JWT_SECRET'], algorithms=['HS256'])
        
        if decoded.get('email') == email:
            return {
                'verified': True,
                'message': 'verified'
            }
        else:
            return {
                'verified': False,
                'message': 'invalid user'
            }
    except jwt.ExpiredSignatureError:
        return {
            'verified': False,
            'message': 'token expired'
        }
    except jwt.DecodeError:
        return {
            'verified': False,
            'message': 'invalid token'
        }